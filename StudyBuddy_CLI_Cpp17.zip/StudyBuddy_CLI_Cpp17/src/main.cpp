
#include "cli.h"
int main() {
    CLI cli;
    return cli.run();
}
